#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Matrix {
public: 
	int data[20][10];
	int repeat_row_index;
	// Passes a a string and populates data matrix. 
	// While data comes in, populate data by keeping track of counter and row
	void readinput(char* input_file){
		// cout << "char* input_file is : "<<input_file<< "| *input_file is : "
		// << *input_file<< endl;
		ifstream myfile(input_file);
		// ifstream myfile("input.txt");
		if(myfile.is_open()){
			int counter = 0;
			int row = 0;
			int tmp;
			while (myfile >> tmp){
				// data[counter&10][row] = tmp;
				data[row][counter%10] = tmp;
				cout << data[row][counter%10] << "  ";
				// cout << tmp << "  ";
				if((counter+1)%10==0){
					row++;
					cout<<endl;
				}
				counter++;}
				myfile.close();
		}
		else{
			cout << "Unable to open file."<<endl;
		}
	}
	// Returns next row where x occurs. Linear search brute force.
	// If data[i][j] = x then return that coordinate.
	int linear_search(int x, int* I){
		int counter = 0;
		int flag = 0;
		// Note: i = 1 not i = 0 -> starts at second row
		for (int i =1; i <20; i++){
			for(int j = 0; j<10 ; j++){
				counter++;
				// cout << counter <<" "<<i<<","<<j<<" " << data[j][i]<< endl;
				
				if(data[i][j] == x){
					// cout << "triggered";
					flag = 1;
					*I = counter;
					return i+1;  // Skipped first row.
				}
			}
		}
		cout << "X not found."<<endl;
		return -1;
	}

	// Implementation of borrowed code
	void sort_row(int rownum){
		bubbleSort(data[rownum-1],10);
	}
	// Bubble sort
	void swap(int *xp, int *yp) 
	{ 
	    int temp = *xp; 
	    *xp = *yp; 
	    *yp = temp; 
	}  
	// Optimized Bubble Sort 
	void bubbleSort(int arr[], int n) 
	{ 
	   int i, j; 
	   bool swapped; 
	   for (i = 0; i < n-1; i++) 
	   { 
	     swapped = false; 
	     for (j = 0; j < n-i-1; j++) 
	     { 
	        if (arr[j] > arr[j+1]) 
	        { 
	           swap(&arr[j], &arr[j+1]); 
	           swapped = true; 
	        } 
	     } 
  
	     // If nothing changed, break 
	     if (swapped == false) 
	        break; 
	    } 
	}

	// Taken from Geeks for Geeks. Iteration counter added.
	int binarySearch(int arr[], int l, int r, int x, int *I) { 	
	    *I = *I +1;
	    // cout <<  "Iterator: "<< *I << " ";
	    if (r >= l) { 
	        int mid = l + (r - l) / 2; 
	  
	        // If the element is present at the middle 
	        // itself 
	        if (arr[mid] == x)
	            return mid; 
	        // If element is smaller than mid, then 
	        // it can only be present in left subarray 
	        if (arr[mid] > x) 
	            return binarySearch(arr, l, mid - 1, x, I); 
	  		
	        // Else the element can only be present 
	        // in right subarray 
	        return binarySearch(arr, mid + 1, r, x, I); 
	        
	    } 
	  
	    // We reach here when element is not 
	    // present in array 
	    return -1; 
} 
};

int main(int argc, char* argv[]){
	char* filename = argv[1];
	cout << filename << endl;
	Matrix a;
	a.readinput(filename);
	int I,R, I2;
	// Run linear search
	R = a.linear_search(a.data[0][0],&I);
	// R = a.linear_search(7777777,&I);
	a.sort_row(R);
	// Syntax for write file
	ofstream write(argv[2]);
	// Run binary search
	I2 = 0;
	int location = a.binarySearch(a.data[R-1], 0, 10, a.data[0][0], &I2);
	if(write.is_open()){
		// cout << "Row: " << R 
		// << "  Iteration time: "<< I<< endl;
		write << "Row found: " << R
		<< "    Iteration count: "<< I<< endl <<"Sorted Row: ";
		for(int l =0; l < 10; l++){
			write << a.data[R-1][l]<<" ";
		}

		write <<endl<< "Location: " << location+1
		<< "   Iteration count:"<< I2<<endl;
	}
	else{
		cout << "Could not open output file."<< endl;
	}

	

	
}
/* Notes:
Feb.17,2020. Having a lot of trouble just inputting data[20][10].
Order of the indexes seems to be reversed. Sovled: just a problem
with the indexing operations.
*/