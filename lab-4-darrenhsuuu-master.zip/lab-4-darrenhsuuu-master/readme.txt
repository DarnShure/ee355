Darren Hsu
Feb. 17,2020
8787302072
Usage: run the compiled code with input.txt and output.txt after.

Description: main.cpp reads an input file that is formatted as a 20x10 matrix.
It puts the values in a public attribute data[20][10]. It has 3 methods. The first is linear search. It searches for any given recurring values starting from row two.
Bubble sort is used as the sorting algorithm. Binary search is used to search. Both algorithms were from Geeks for Geeks.com

To write my sorting algorithm, I took directly from Geeks for Geek buble sort page: https://www.geeksforgeeks.org/bubble-sort/

Geeks for geeks was alos refrenced in binary search: https://www.geeksforgeeks.org/binary-search/